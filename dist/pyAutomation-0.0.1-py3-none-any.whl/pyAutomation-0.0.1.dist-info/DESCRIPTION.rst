pyAutomation is a library of classes that allows for building of complex control systems. It provides both data structures and process supervision utilities.



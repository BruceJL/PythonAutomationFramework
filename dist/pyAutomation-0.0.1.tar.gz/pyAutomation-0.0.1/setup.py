import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="pyAutomation",
    version="0.0.1",
    author="Bruce Link",
    author_email="bruce.j.e.link@gmail.com",
    description="A automation framework for building control and automation projects.",
    long_description="pyAutomation is a library of classes that allows for building of " + \
        "complex control systems. It provides both data structures and process " + \
        "supervision utilities." ,
    long_description_content_type="text/markdown",
    url="https://github.com/pypa/sampleproject",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)

Python Automation Frame. I won't waste my pyAutomation.
